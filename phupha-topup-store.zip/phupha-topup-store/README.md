# PhuPha Top Up Store

Mobile-first top up website project.

## Features
- Responsive design
- Clean blue & white UI
- Telegram notification ready
- Admin dashboard ready
- Reusable component structure

## Stack
- HTML
- CSS
- JavaScript
